package com.example.dropnote

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
