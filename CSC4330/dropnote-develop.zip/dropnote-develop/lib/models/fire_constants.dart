class Collections {
  static String users = "users";
  static String files = "files";
}
